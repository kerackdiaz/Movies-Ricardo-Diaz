const images = movies.map(movie => movie.image);
const titles = movies.map(movie => movie.title);

const randomIndices = [];

while (randomIndices.length < 5) {
  const randomIndex = Math.floor(Math.random() * images.length);
  if (!randomIndices.includes(randomIndex)) {
    randomIndices.push(randomIndex);
  }
}

const randomImages = randomIndices.map(index => images[index]);
const randomTitles = randomIndices.map(index => titles[index]);

document.addEventListener('alpine:init', () => {
  Alpine.data('slider', () => ({
    currentIndex: 1,
    images: randomImages,
    titles: randomTitles,
    back() {
      if (this.currentIndex > 1) {
        this.currentIndex = this.currentIndex - 1;
      }
    },
    next() {
      if (this.currentIndex < this.images.length) {
        this.currentIndex = this.currentIndex + 1;
      } else if (this.currentIndex <= this.images.length) {
        this.currentIndex = this.images.length - this.currentIndex + 1
      }
    },
  }))
})



window.addEventListener('scroll', function () {
  const header = document.querySelector('header');

  if (window.scrollY > 0) {
    header.classList.add('bg-transparent');
    header.classList.remove('bg-black');
  } else {
    header.classList.remove('bg-transparent');
    header.classList.add('bg-black');
  }
});





const allGenres = movies.reduce((genres, movie) => {
  movie.genres.forEach(genre => {
    if (!genres.includes(genre)) {
      genres.push(genre);
    }
  });
  return genres;
}, []);


function createGenres(allGenres) {
  const section = document.getElementById('Categories');
  if (section) {
    section.innerHTML = "";
    const buttonHtml = allGenres.reduce((data, genre) => {
      return data + `<button class="genre-btn px-8 py-2 text-2xl ring-2 ring-[#6d38e0] text-white bg-[#6d38e0] rounded-md shadow-[#6d38e0] hover:bg-black hover:text-[#6d38e0] font-bebas-neue capitalize">${genre}</button>`;
    }, "");
    section.innerHTML = buttonHtml;

    const genreButtons = document.querySelectorAll('.genre-btn');
    genreButtons.forEach(button => {
      button.addEventListener('click', () => {
        const selectedGenre = button.textContent;
        createCard(movies, selectedGenre);
      });
    });
  }
}

function createCard(movies, genreFilter = null) {
  const section = document.getElementById('movies');
  if (section) {
    section.innerHTML = "";

    let filteredMovies = movies;
    if (genreFilter) {
      filteredMovies = movies.filter(movie => movie.genres.includes(genreFilter));
    }

    const cardHTML = filteredMovies.reduce((data, movie) => {
      return data + `
        <article class="flex justify-center">
          <div class="w-80 dark:bg-white p-3 bg-gray-900">
            <img class="h-52 w-full object-cover" src="${movie.image}" alt="${movie.title}" />
            <h2 class="text-center font-bold font-bebas-neue capitalize my-4 text-2xl text-white dark:text-black">${movie.title}</h2>
            <p class="text-white dark:text-black">${movie.overview}</p>
          </div>
        </article>
      `;
    }, "");

    section.innerHTML = cardHTML;
  }
}
createGenres(allGenres);
createCard(movies);


let themeToggleDarkIcon = document.getElementById('theme-toggle-dark-icon');
let themeToggleLightIcon = document.getElementById('theme-toggle-light-icon');

// Change the icons inside the button based on previous settings
if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    themeToggleLightIcon.classList.remove('hidden');
} else {
    themeToggleDarkIcon.classList.remove('hidden');
}

let themeToggleBtn = document.getElementById('theme-toggle');

themeToggleBtn.addEventListener('click', function() {


    themeToggleDarkIcon.classList.toggle('hidden');
    themeToggleLightIcon.classList.toggle('hidden');

    if (localStorage.getItem('color-theme')) {
        if (localStorage.getItem('color-theme') === 'light') {
            document.documentElement.classList.add('dark');
            localStorage.setItem('color-theme', 'dark');
        } else {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('color-theme', 'light');
        }

    } else {
        if (document.documentElement.classList.contains('dark')) {
            document.documentElement.classList.remove('dark');
            localStorage.setItem('color-theme', 'light');
        } else {
            document.documentElement.classList.add('dark');
            localStorage.setItem('color-theme', 'dark');
        }
    }
    
});